import type { Metadata } from "next";
import { Fraunces, JetBrains_Mono } from "next/font/google";
import "./globals.css";

/*
  Two fonts, strictly:
  • Fraunces — variable serif (opsz + SOFT + WONK axes) for display,
    body, and italic accents. One family, full dynamic range.
  • JetBrains Mono — small monospace for labels, eyebrows, data.
*/

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  axes: ["opsz", "SOFT", "WONK"],
  display: "swap",
});

const jbMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  weight: ["400", "500", "600"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "humanovo — research intelligence for scientists",
  description:
    "humanovo reads every paper, dataset, and notebook so you can see what the literature missed — and pursue the hypothesis it points to.",
  icons: { icon: "/favicon.svg" },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${fraunces.variable} ${jbMono.variable}`}>
      <body>{children}</body>
    </html>
  );
}
