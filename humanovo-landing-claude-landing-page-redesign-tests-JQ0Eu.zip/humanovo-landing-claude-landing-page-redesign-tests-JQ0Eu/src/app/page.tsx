"use client";

import Navigation, {
  OverlayProvider,
  ContactOverlay,
} from "@/components/Navigation";
import AuroraBackdrop from "@/components/AuroraBackdrop";
import Page1Hero from "@/components/Page1Hero";
import Page2Pipeline from "@/components/Page2Pipeline";
import PageDownload from "@/components/PageDownload";
import PlatformLock from "@/components/PlatformLock";

export default function Home() {
  return (
    <OverlayProvider>
      <PlatformLock />
      <AuroraBackdrop />
      <Navigation />
      <ContactOverlay />
      <main style={{ position: "relative", zIndex: 1 }}>
        <Page1Hero />
        <Page2Pipeline />
        <PageDownload />
      </main>
    </OverlayProvider>
  );
}
